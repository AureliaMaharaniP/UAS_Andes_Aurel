<!--  Footer  -->
<footer class="main-footer">
    <div class="container">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2017 <a href="#">Mentoring Studio</a>.</strong> All rights
        reserved.
    </div>
</footer>
<!-- /.Footer -->