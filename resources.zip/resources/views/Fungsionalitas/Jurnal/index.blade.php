@extends("layout.app")

@section('content')
    <div class="container">
        <div class="row">
            <div>
                <div class="box">
                    <div class="col-md-6 ">
                        <form action="">
                            testt
                        </form>
                    </div>
                </div>
                <div class="box">
                    <div class="col-md-6 ">
                        <form action="">
                            <div class="form-group">
                                <input class="form-control" type="text" name="" placeholder="input">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection